<?php
require_once('vendor/autoload.php');

// reference the Dompdf namespace
use Dompdf\Dompdf;

$dompdf = new Dompdf();
// Enable the HTML5 parser to tolerate poorly formed HTML
$dompdf->set_option('isHtml5ParserEnabled', true);

// Load into DomPDF from the external HTML file
// This is located within the same directory
$content = file_get_contents('sample.html');
$dompdf->loadHtml($content);

// Render and donwload the generated PDF
$dompdf->render();
$dompdf->stream('html-to-pdf.pdf');