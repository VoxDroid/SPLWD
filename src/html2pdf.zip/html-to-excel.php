<?php

// We'll make sure errors and notices are disabled,
// otherwise this can interfere with the generated content
// and the exported file won't display
// ini_set('display_errors', 0);

require_once('vendor/autoload.php');

// Pull in the HTML contents, and convert to XML
$data = file_get_contents('sample.html');

try {

	$dom = new DOMDocument();
	$dom->loadHTML( $data );

	// Get all tables in the document
	$tables = $dom->getElementsByTagName('table');

	// The array we'll store the table data in
	$tableData = array();

	foreach($tables as $tableN => $table) {
		// This requires properly formatted HTML table structure
		$head = $table->getElementsByTagName('thead')[0];
		$body = $table->getElementsByTagName('tbody')[0];

		// Table heading - assuming there is a heading directly before the table
		$tableData[] = array(
			'heading' => 'Table '.($tableN+1),
			'tableData' => array()
		);

		if($head && $body) {

			foreach($head->getElementsByTagName('tr')[0]->getElementsByTagName('th') as $colN => $headCell) {
				$tableData[$tableN]['tableData']['headings'][] = $headCell->nodeValue;
			}

			foreach($body->getElementsByTagName('tr') as $rowN => $tableRow) {
				foreach($tableRow->getElementsByTagName('td') as $colN => $tableCell) {
					$tableData[$tableN]['tableData']['rows'][$rowN][$colN] = $tableCell->nodeValue;
				}
			}

		}
	  
	}

} catch(\Exception $e) {
	// We failed...
	exit;
}

// Instantiate the PHPExcel object
$objPHPExcel = new PHPExcel();

$objPHPExcel->getProperties()->setCreator("Robin Metcalfe")
							 ->setLastModifiedBy("Robin Metcalfe")
							 ->setTitle("HTML Tables To Excel Test")
							 ->setSubject("Solarise Design")
							 ->setDescription("A test document for converting HTML tables into Excel.")
							 ->setKeywords("office PHPExcel php")
							 ->setCategory("Test result file");

$alphabet = range('A', 'Z');

foreach($tableData as $tableN => $data) {

	if($tableN > 0) {
		$objPHPExcel->createSheet($tableN);
	}

	$sheet = $objPHPExcel->setActiveSheetIndex($tableN);
	$objPHPExcel->getActiveSheet()->setTitle($data['heading']);

	foreach($data['tableData']['headings'] as $n => $heading) {
		$sheet->setCellValue("{$alphabet[$n]}1", $heading);
	}

	foreach($data['tableData']['rows'] as $rowN => $rowData) {
		foreach($rowData as $colN => $value) {
			$n = $rowN + 2;
			$sheet->setCellValue("{$alphabet[$colN]}{$n}", $value);
		}		
		
	}

}

// Resize columns to fit data, just to tidy things up
foreach(range('A','Z') as $columnID) {
	$objPHPExcel
		->getActiveSheet()
		->getColumnDimension($columnID)
        ->setAutoSize(true);
}

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="html-to-excel.xls"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');